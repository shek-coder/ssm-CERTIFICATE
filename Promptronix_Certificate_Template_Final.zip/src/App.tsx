import { useMemo, useState } from 'react'
import { jsPDF } from 'jspdf'
import { ArrowLeft, ArrowRight, BadgeCheck, Check, ChevronRight, CircleHelp, Code2, Download, ExternalLink, Gamepad2, Layers3, Sparkles, WandSparkles } from 'lucide-react'
import ssmHeader from './assets/ssm-header.png'
import iicLogo from './assets/iic-logo.png'
import csiLogo from './assets/csi-logo.png'

type Stage = 'name' | 'usage' | 'project' | 'certificate'
type Project = {
  name: string
  description: string
  prompt: string
  tool: string
}

const tools = [
  { name: 'VS Code', detail: 'Local code editor', icon: Code2 },
  { name: 'Replit', detail: 'Browser-based coding', icon: Layers3 },
  { name: 'Google AI Studio', detail: 'Gemini-powered building', icon: Sparkles },
  { name: 'Gemini', detail: 'AI assistant', icon: WandSparkles },
  { name: 'ChatGPT', detail: 'AI-assisted coding', icon: CircleHelp },
  { name: 'Cursor', detail: 'AI code editor', icon: Code2 },
  { name: 'Cloud IDE', detail: 'Other online workspace', icon: Layers3 },
  { name: 'Other', detail: 'Another coding tool', icon: CircleHelp },
]

function App() {
  const [stage, setStage] = useState<Stage>('name')
  const [fullName, setFullName] = useState('')
  const [usedPromptronix, setUsedPromptronix] = useState<boolean | null>(null)
  const [project, setProject] = useState<Project>({ name: '', description: '', prompt: '', tool: '' })
  const [message, setMessage] = useState('')
  const [downloading, setDownloading] = useState(false)

  const issueDate = useMemo(() => new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }).format(new Date()), [])
  const progress = stage === 'name' ? 1 : stage === 'usage' ? 2 : stage === 'project' ? 3 : 4
  const updateProject = (key: keyof Project, value: string) => setProject(current => ({ ...current, [key]: value }))

  function startCertificate() {
    setMessage('')
    setStage('certificate')
  }

  async function downloadCertificate() {
    const ssmImage = document.getElementById('certificate-ssm-logo') as HTMLImageElement | null
    const iicImage = document.getElementById('certificate-iic-logo') as HTMLImageElement | null
    const csiImage = document.getElementById('certificate-csi-logo') as HTMLImageElement | null
    const images = [ssmImage, iicImage, csiImage]
    if (images.some(image => !image || !image.complete || image.naturalWidth === 0)) {
      setMessage('The certificate logos are still loading. Please try again in a moment.')
      return
    }
    setDownloading(true)
    setMessage('')
    try {
      const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4', compress: true })
      const pageW = 297
      const pageH = 210
      const mid = pageW / 2
      pdf.setFillColor(255, 255, 255)
      pdf.rect(0, 0, pageW, pageH, 'F')

      // The approved reference layout: a compact SSM header on the left, IIC/CSI on the right.
      pdf.setDrawColor(255, 77, 26)
      pdf.setLineWidth(0.8)
      pdf.roundedRect(5, 5, 287, 200, 2, 2, 'S')
      pdf.setDrawColor(214, 165, 63)
      pdf.setLineWidth(0.35)
      pdf.roundedRect(7.5, 7.5, 282, 195, 1.5, 1.5, 'S')

      const ssmW = 183
      const ssmH = ssmW * (ssmImage!.naturalHeight / ssmImage!.naturalWidth)
      pdf.addImage(ssmImage!, 'PNG', 11.5, 7.8, ssmW, ssmH, undefined, 'FAST')

      const iicW = 38
      const iicH = iicW * (iicImage!.naturalHeight / iicImage!.naturalWidth)
      pdf.addImage(iicImage!, 'PNG', 202, 9.5, iicW, iicH, undefined, 'FAST')
      pdf.setDrawColor(214, 165, 63)
      pdf.setLineWidth(0.45)
      pdf.line(247.5, 12, 247.5, 34)
      pdf.addImage(csiImage!, 'PNG', 254, 8.5, 25, 25, undefined, 'FAST')

      const dividerY = 40
      pdf.setDrawColor(214, 165, 63)
      pdf.setLineWidth(0.5)
      pdf.line(13, dividerY, 284, dividerY)

      pdf.setTextColor(10, 19, 39)
      pdf.setFont('times', 'bold')
      pdf.setFontSize(24)
      pdf.text('CERTIFICATE OF ACHIEVEMENT', mid, 56, { align: 'center' })

      pdf.setFont('times', 'italic')
      pdf.setFontSize(12)
      pdf.setTextColor(88, 98, 117)
      pdf.text('This certificate is presented to', mid, 73, { align: 'center' })

      pdf.setFont('times', 'bold')
      pdf.setFontSize(29)
      pdf.setTextColor(255, 77, 26)
      pdf.text(fullName.trim(), mid, 86, { align: 'center', maxWidth: 240 })
      pdf.setDrawColor(214, 165, 63)
      pdf.setLineWidth(0.75)
      pdf.line(87, 96, 210, 96)

      pdf.setFont('times', 'normal')
      pdf.setFontSize(11.5)
      pdf.setTextColor(10, 19, 39)
      pdf.text('For being a brave young innovator who created a project with AI. Keep trying new ideas and keep shining!', mid, 108, { align: 'center', maxWidth: 260 })

      pdf.setFont('helvetica', 'bold')
      pdf.setFontSize(13)
      pdf.setTextColor(10, 19, 39)
      pdf.text(`APPLICATION NAME: ${project.name.trim()}`, mid, 126, { align: 'center', maxWidth: 255 })

      pdf.setFont('helvetica', 'normal')
      pdf.setFontSize(10)
      pdf.setTextColor(83, 91, 108)
      pdf.text(`Built with: ${project.tool}`, mid, 137, { align: 'center', maxWidth: 250 })

      pdf.setFont('helvetica', 'bold')
      pdf.setFontSize(11)
      pdf.setTextColor(255, 77, 26)
      pdf.text('Dream Big. Learn More. Keep Creating!', mid, 151, { align: 'center' })

      // Open footer spacing matches the reference; no certificate ID or extra category labels.
      pdf.setDrawColor(210, 214, 222)
      pdf.setLineWidth(0.45)
      pdf.line(13, 164, 284, 164)

      pdf.setFont('helvetica', 'bold')
      pdf.setFontSize(10.5)
      pdf.setTextColor(10, 19, 39)
      pdf.text('SHRIRAM K', 57, 176, { align: 'center' })
      pdf.text('SHEK FAREETH M', 240, 176, { align: 'center' })

      pdf.setFont('helvetica', 'normal')
      pdf.setFontSize(8.5)
      pdf.setTextColor(100, 107, 121)
      pdf.text('EVENT COORDINATOR', 57, 184, { align: 'center' })
      pdf.text('EVENT COORDINATOR', 240, 184, { align: 'center' })

      pdf.setFontSize(7.5)
      pdf.text('ISSUED ON', mid, 175, { align: 'center' })
      pdf.setFont('helvetica', 'bold')
      pdf.setFontSize(9.5)
      pdf.setTextColor(10, 19, 39)
      pdf.text(issueDate, mid, 183, { align: 'center' })

      pdf.save(`Promptronix-Certificate-${fullName.trim().replace(/[^a-z0-9]+/gi, '-')}.pdf`)
    } catch (error) {
      console.error(error)
      setMessage('Could not generate the PDF. Please try again.')
    } finally {
      setDownloading(false)
    }
  }

  const restart = () => {
    setStage('name')
    setFullName('')
    setUsedPromptronix(null)
    setProject({ name: '', description: '', prompt: '', tool: '' })
    setMessage('')
  }

  return (
    <main className="app-shell">
      <div className="glow glow-one" /><div className="glow glow-two" />
      <header className="topbar">
        <a className="brand" href="#top" onClick={event => { event.preventDefault(); restart() }}>
          <span className="brand-mark"><WandSparkles size={21} /></span>
          <span>promptronix<span className="brand-dot">.</span><small>AI PROJECT JOURNEY</small></span>
        </a>
        <div className="top-pill"><span className="live-dot" /> Guided experience <ChevronRight size={15} /></div>
      </header>

      <section className="hero" id="top">
        <div className="eyebrow"><Sparkles size={14} /> BUILD SOMETHING WITH AI</div>
        <h1>One prompt can start<br /><span>something brilliant.</span></h1>
        <p className="hero-copy">Tell us about your Promptronix journey. Share what you built, choose the tools you used, and create your participation certificate.</p>
      </section>

      <section className="journey-card">
        <div className="progress-header">
          <div><span className="step-count">STEP {progress} <span>/ 4</span></span><div className="step-label">{stage === 'name' ? 'Let’s get to know you' : stage === 'usage' ? 'Your Promptronix journey' : stage === 'project' ? 'Show us what you built' : 'Your certificate is ready'}</div></div>
          <div className="progress-dots" aria-label={`Step ${progress} of 4`}>{[1, 2, 3, 4].map(n => <span key={n} className={n <= progress ? 'active' : ''} />)}</div>
        </div>

        {stage === 'name' && <div className="step-content fade-in">
          <div className="step-icon"><Sparkles size={23} /></div>
          <h2>First, what should we call you?</h2>
          <p className="muted">Your name will appear on your certificate exactly as you enter it here.</p>
          <label htmlFor="fullName">Your full name</label>
          <input id="fullName" className="text-input" value={fullName} onChange={e => setFullName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && fullName.trim()) setStage('usage') }} placeholder="e.g. Shriram K" maxLength={70} autoComplete="name" />
          <div className="helper-row"><span>Use the name you want printed on the certificate.</span><span>{fullName.length}/70</span></div>
          <button className="primary-btn full-btn" disabled={!fullName.trim()} onClick={() => setStage('usage')}>Continue <ArrowRight size={18} /></button>
        </div>}

        {stage === 'usage' && <div className="step-content fade-in">
          <div className="step-icon"><WandSparkles size={23} /></div>
          <h2>Have you used Promptronix?</h2>
          <p className="muted">We’ll use your answer to guide you to the next step.</p>
          <div className="choice-grid">
            <button className={`choice-card ${usedPromptronix === true ? 'selected' : ''}`} onClick={() => setUsedPromptronix(true)}><span className="choice-icon yes-icon"><Check size={21} /></span><strong>Yes, I used it</strong><small>I built or explored a project using Promptronix.</small><span className="choice-check">{usedPromptronix === true && <Check size={15} />}</span></button>
            <button className={`choice-card ${usedPromptronix === false ? 'selected' : ''}`} onClick={() => setUsedPromptronix(false)}><span className="choice-icon no-icon"><ExternalLink size={20} /></span><strong>Not yet</strong><small>I’d like to try Promptronix first.</small><span className="choice-check">{usedPromptronix === false && <Check size={15} />}</span></button>
          </div>
          {usedPromptronix === false && <div className="notice"><CircleHelp size={18} /><div><strong>Start with Promptronix</strong><p>Open Promptronix, try creating an app, and return here when you're ready to share your project.</p><a href="https://promptronix.vercel.app/" target="_blank" rel="noreferrer">Open Promptronix <ExternalLink size={13} /></a></div></div>}
          <div className="button-row"><button className="secondary-btn" onClick={() => setStage('name')}><ArrowLeft size={17} /> Back</button><button className="primary-btn" disabled={usedPromptronix === null || usedPromptronix === false} onClick={() => setStage('project')}>Next step <ArrowRight size={18} /></button></div>
        </div>}

        {stage === 'project' && <div className="step-content fade-in">
          <div className="step-icon"><Gamepad2 size={23} /></div>
          <h2>What did you build?</h2>
          <p className="muted">A game, a useful website, an AI tool — every idea counts.</p>
          <div className="form-grid">
            <div className="field full-field"><label htmlFor="projectName">Application name <span className="required">*</span></label><input id="projectName" className="text-input" value={project.name} onChange={e => updateProject('name', e.target.value)} placeholder="Enter your application name" maxLength={90} /></div>
            <div className="field full-field"><label>Which vibe-coding / AI tool did you use? <span className="required">*</span></label><div className="tool-grid">{tools.map(({ name, detail, icon: Icon }) => <button type="button" key={name} className={`tool-option ${project.tool === name ? 'selected' : ''}`} onClick={() => updateProject('tool', name)}><Icon size={17} /><span><strong>{name}</strong><small>{detail}</small></span>{project.tool === name && <Check size={15} className="tool-check" />}</button>)}</div></div>
            <div className="field full-field"><label htmlFor="description">What does your project do? <span className="optional">Optional</span></label><textarea id="description" className="text-input textarea" value={project.description} onChange={e => updateProject('description', e.target.value)} placeholder="Describe your app in one or two sentences..." rows={3} maxLength={400} /><div className="helper-row"><span>Keep it simple and clear.</span><span>{project.description.length}/400</span></div></div>
            <div className="field full-field"><label htmlFor="prompt">What prompt did you use? <span className="optional">Optional</span></label><textarea id="prompt" className="text-input textarea" value={project.prompt} onChange={e => updateProject('prompt', e.target.value)} placeholder="Describe the prompt you used to build your application..." rows={3} maxLength={1200} /><div className="helper-row"><span>Your prompt helps describe your creative process.</span><span>{project.prompt.length}/1200</span></div></div>
          </div>
          {message && <p className="error-message">{message}</p>}
          <div className="button-row"><button className="secondary-btn" onClick={() => setStage('usage')}><ArrowLeft size={17} /> Back</button><button className="primary-btn" onClick={() => { if (!project.name.trim()) { setMessage('Please enter your project name.'); return } if (!project.tool) { setMessage('Please select the tool you used.'); return } startCertificate() }}>Generate certificate <ArrowRight size={18} /></button></div>
        </div>}

        {stage === 'certificate' && <div className="step-content certificate-step fade-in">
          <div className="success-heading"><div className="success-icon"><BadgeCheck size={25} /></div><div><div className="eyebrow success-eyebrow">PROJECT JOURNEY COMPLETE</div><h2>Well done, {fullName.split(' ')[0]}!</h2><p className="muted">Your certificate preview is ready. Download it as a print-ready PDF.</p></div></div>
          <div className="certificate-preview" id="certificate-preview">
            <div className="certificate-inner">
              <div className="certificate-header">
                <img src={ssmHeader} id="certificate-ssm-logo" className="certificate-ssm-logo" alt="SSM Institute of Engineering and Technology — An Autonomous Institution" />
                <div className="certificate-partner-logos">
                  <img src={iicLogo} id="certificate-iic-logo" className="certificate-iic-logo" alt="Institution’s Innovation Council" />
                  <span className="certificate-logo-divider" aria-hidden="true" />
                  <img src={csiLogo} id="certificate-csi-logo" className="certificate-csi-logo" alt="Computer Society of India" />
                </div>
              </div>
              <div className="cert-rule" />
              <h3>CERTIFICATE OF ACHIEVEMENT</h3>
              <p className="cert-presented">This certificate is presented to</p>
              <div className="cert-recipient">{fullName.trim()}</div>
              <div className="cert-underline" />
              <p className="cert-body">For being a brave young innovator who created a project with AI. Keep trying new ideas and keep shining!</p>
              <div className="cert-project"><span>Application Name:</span> {project.name.trim()}</div>
              <p className="cert-meta">Built with: {project.tool}</p>
              <p className="cert-tagline">Dream Big. Learn More. Keep Creating!</p>
              <div className="cert-footer"><div><strong>SHRIRAM K</strong><span>EVENT COORDINATOR</span></div><div className="cert-date">ISSUED ON<strong>{issueDate}</strong></div><div><strong>SHEK FAREETH M</strong><span>EVENT COORDINATOR</span></div></div>
            </div>
          </div>
          <div className="certificate-actions"><button className="primary-btn download-btn" onClick={downloadCertificate} disabled={downloading}><Download size={18} /> {downloading ? 'Preparing PDF…' : 'Download certificate PDF'}</button><button className="secondary-btn" onClick={restart}>Start again <ArrowRight size={16} /></button></div>
          {message && <p className="error-message">{message}</p>}
        </div>}
      </section>
      <footer className="footer"><span>© {new Date().getFullYear()} Promptronix AI Project Journey</span><span>Made for curious builders <Sparkles size={13} /></span></footer>
    </main>
  )
}

export default App
