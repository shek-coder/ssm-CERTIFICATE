# Promptronix AI Project Journey

A React + Vite project that guides a participant through:

1. Entering their name.
2. Confirming whether they used Promptronix.
3. Entering an application name, selecting an AI or vibe-coding tool, and optionally describing the application and prompt.
4. Previewing and downloading an A4 landscape participation certificate as PDF.

## Certificate details

- Uses the SSM Institute of Engineering and Technology header image on the left and the supplied Institution’s Innovation Council and CSI logos on the right. Logo assets are in `src/assets/`.
- Prints the participant's name, the label “Application Name:” with the entered application name, and “Built with:” followed by the selected AI / vibe-coding tool. No sample category labels are printed on the certificate.
- Uses the Young Innovator certificate message: “For being a brave young innovator who created a project with AI. Keep trying new ideas and keep shining!”
- Includes the tagline: “Dream Big. Learn More. Keep Creating!”
- Shows **SHRIRAM K** and **SHEK FAREETH M** as Event Coordinators.
- Does not include Head of Department or Mentor sections.
- The approved certificate template does not display a certificate ID, category examples, or the “Promptronix AI Project Journey” line.

## Run locally

Requirements: Node.js 18 or later.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

The deployable static site is generated in `dist/`. It can be deployed to Vercel with the Vite framework preset and build command `npm run build`; output directory `dist`.

## Notes

This version is frontend-only and does not store submissions on a server. The Google Fonts import is optional; system font fallbacks are included. Use only institutional branding you have permission to display.
